package com.example.myrecycleview

data class Person (
    val name: String,
    val age: String,
    val photoId :Int
    )